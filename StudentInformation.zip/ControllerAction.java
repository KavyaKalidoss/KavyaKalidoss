package p1;

import java.sql.Statement;

import java.util.ArrayList;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ControllerAction {
	static Connection con=null;
	Statement st;
	ResultSet rs;
	static Connection getConnections(){
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			try {
				con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","prasanth20","prasanth20");
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return con;
		
	}
	
	boolean status=false;
	public boolean insert(StudentinfoBean sb){
		
		String name=sb.getName();
		String age=sb.getAge();
		String email=sb.getEmail();
		String phonenumber=sb.getPhonenumber();
		String Date=sb.getDate();
		
		try {
			st = getConnections().createStatement();
			rs=st.executeQuery("select * from  Studentinfo where name='"+name+"'");
			if(rs.next()){
				status=false;
			}
			else{
				int i=st.executeUpdate("insert into Studentinfo values('"+name+"','"+age+"','"+email+"','"+phonenumber+"','"+Date+"')");
				if(i>0){
					status=true;
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				
		return status;
					
	}
	public ResultSet fetch(String name){
		
			try {
		
				st = getConnections().createStatement();
				rs=st.executeQuery("select * from  Studentinfo where name='"+name+"'");
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		return rs;
			}
	
	public ArrayList<StudentinfoBean> fetchall() {
			ArrayList<StudentinfoBean> al=new ArrayList<StudentinfoBean>();
		try {
			st=getConnections().createStatement();
			rs=st.executeQuery("select * from Studentinfo");
			while(rs.next()){
				StudentinfoBean sib=new StudentinfoBean();
				sib.setName(rs.getString(1));
				sib.setAge(rs.getString(2));
				sib.setEmail(rs.getString(3));
				sib.setPhonenumber(rs.getString(4));
				sib.setDate(rs.getString(5));
				al.add(sib);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		return al;
	}
	public boolean update(StudentinfoBean sb) {
		
		String name=sb.getName();
		String age=sb.getAge();
		String email=sb.getEmail();
		String phonenumber=sb.getPhonenumber();
		String Date=sb.getDate();
		
		try {
			st = getConnections().createStatement();
			int i=st.executeUpdate("update Studentinfo set name='"+name+"',age='"+age+"',email='"+email+"',phonenumber='"+phonenumber+"',doj='"+Date+"' where name='"+name+"'");
			if(i>0){
				status=true;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				
		return status;

	}
	public boolean delete(String name) {
	
		try {
			st = getConnections().createStatement();
			int i=st.executeUpdate("delete Studentinfo where name='"+name+"'");
			if(i>0){
				status=true;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				
		
		return status;
	}

}
