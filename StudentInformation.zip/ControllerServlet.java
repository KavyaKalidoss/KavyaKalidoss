

import java.io.IOException;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import p1.ControllerAction;
import p1.StudentinfoBean;

/**
 * Servlet implementation class ControllerServlet
 */
@WebServlet("/ControllerServlet")
public class ControllerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public ControllerServlet() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	String action=request.getParameter("action");
	if(action.equals("insert")){
		doInsert(request,response);
	}
	else if(action.equals("fetch"))
	{
		dofetch(request,response);
	}
	else if(action.equals("fetchall")){
		dofetchall(request,response);
		
	}
	else if(action.equals("update")){
		doupdate(request,response);
	}
	else if(action.equals("delete")){
		doDeletes(request,response);
	
	}
	}
	private void doDeletes(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name=request.getParameter("name");
		
		ControllerAction contact=new ControllerAction();
		
		boolean status=contact.delete(name);
		if(status){
			
			RequestDispatcher rd=getServletContext().getRequestDispatcher("/ControllerServlet?action=fetchall");
			rd.forward(request, response);
			
		}
		else{
			response.sendRedirect("Index.jsp");
			
		}	
		
		}

		
	private void doupdate(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String name=request.getParameter("name");
		String age=request.getParameter("age");
		String email=request.getParameter("email");
		String phone=request.getParameter("phonenumber");
		String date=request.getParameter("Date");
		
	StudentinfoBean std=new StudentinfoBean();	
	
	std.setName(name);
	std.setAge(age);
	std.setEmail(email);
	std.setPhonenumber(phone);
	std.setDate(date);
	
	ControllerAction contact=new ControllerAction();
	
	boolean status=contact.update(std);
	if(status){
		
		RequestDispatcher rd=getServletContext().getRequestDispatcher("/ControllerServlet?action=fetchall");
		rd.forward(request, response);
		
	}
	else{
		response.sendRedirect("Index.jsp");
		
	}	
	
	}

	private void dofetchall(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		ControllerAction contact=new ControllerAction();
		
		ArrayList<StudentinfoBean> status=contact.fetchall();
		if(status!=null){
			request.setAttribute("al",status);
			RequestDispatcher rd=getServletContext().getRequestDispatcher("/FetchAllSucess.jsp");
			rd.forward(request, response);
			
		}
		else{
			response.sendRedirect("FetchAll.jsp");
			
		}	

	}

	private void dofetch(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String name=request.getParameter("name");
		
		ControllerAction contact=new ControllerAction();
		
	ResultSet status=contact.fetch(name);
		if(status!=null){
			request.setAttribute("rs",status);
			RequestDispatcher rd=getServletContext().getRequestDispatcher("/FetchSuccess.jsp");
			rd.forward(request, response);
		}
		else{
			response.sendRedirect("FetchForm.jsp");
		}
	}

	protected void doInsert(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name=request.getParameter("name");
		String age=request.getParameter("age");
		String email=request.getParameter("email");
		String phone=request.getParameter("phonenumber");
		String date=request.getParameter("Date");
		
	StudentinfoBean std=new StudentinfoBean();	
	
	std.setName(name);
	std.setAge(age);
	std.setEmail(email);
	std.setPhonenumber(phone);
	std.setDate(date);
	
	ControllerAction contact=new ControllerAction();
	
	boolean status=contact.insert(std);
	if(status){
		
		RequestDispatcher rd=getServletContext().getRequestDispatcher("/AddStudent.jsp");
		rd.forward(request, response);
		
	}
	else{
		response.sendRedirect("Index.jsp");
		
	}	
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
